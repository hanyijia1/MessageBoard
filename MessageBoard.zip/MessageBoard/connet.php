<?php  
    define('DB_HOST', 'localhost');  
    define('DB_USER', 'root');  
    define('DB_PWD', 'root');  //我数据库密码
    define('DB_CHARSET', 'UTF8');  
    define('DB_DBNAME', 'my1');  
?>