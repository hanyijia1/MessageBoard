﻿# Host: localhost  (Version: 5.5.53)
# Date: 2019-06-30 01:06:27
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "tbl_ms"
#

DROP TABLE IF EXISTS `tbl_ms`;
CREATE TABLE `tbl_ms` (
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Structure for table "tbl_ms1"
#

DROP TABLE IF EXISTS `tbl_ms1`;
CREATE TABLE `tbl_ms1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(25) NOT NULL,
  `title` varchar(225) DEFAULT NULL,
  `author` varchar(25) DEFAULT NULL,
  `ip` varchar(25) DEFAULT NULL,
  `liuyan` varchar(225) DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  CONSTRAINT `tbl_ms1_ibfk_1` FOREIGN KEY (`user`) REFERENCES `tbl_ms` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
